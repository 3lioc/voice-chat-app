import 'package:flutter/material.dart';

void main() => runApp(const VoiceChatApp());

class VoiceChatApp extends StatelessWidget {
  const VoiceChatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'مجلس الملوك',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF121212),
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.pinkAccent,
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      locale: const Locale('ar'),
      home: const MainNavigator(),
    );
  }
}

class MainNavigator extends StatefulWidget {
  const MainNavigator({super.key});

  @override
  State<MainNavigator> createState() => _MainNavigatorState();
}

class _MainNavigatorState extends State<MainNavigator> {
  int index = 0;

  final screens = const [
    ProfileScreen(),
    VoiceRoomScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: IndexedStack(index: index, children: screens),
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (value) => setState(() => index = value),
          backgroundColor: const Color(0xFF1E1E1E),
          indicatorColor: Colors.pinkAccent.withValues(alpha: .25),
          destinations: const [
            NavigationDestination(
              icon: Icon(Icons.person_outline),
              selectedIcon: Icon(Icons.person),
              label: 'الملف الشخصي',
            ),
            NavigationDestination(
              icon: Icon(Icons.mic_none),
              selectedIcon: Icon(Icons.mic),
              label: 'الغرفة الصوتية',
            ),
          ],
        ),
      ),
    );
  }
}

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('الملف الشخصي'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            onPressed: () {},
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const CircleAvatar(
              radius: 48,
              backgroundColor: Colors.pinkAccent,
              child: Icon(Icons.person, size: 54, color: Colors.white),
            ),
            const SizedBox(height: 10),
            const Text(
              'القيثاره نيوز',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const Text(
              'ID: dmar1',
              style: TextStyle(color: Colors.grey),
            ),
            const SizedBox(height: 24),
            const Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                StatItem(title: 'المتابعة', count: '1'),
                StatItem(title: 'المتابعين', count: '381'),
                StatItem(title: 'الزوار', count: '2.5K'),
              ],
            ),
            const SizedBox(height: 24),
            GridView.count(
              crossAxisCount: 4,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: .9,
              children: const [
                MenuCard(title: 'مهمة', icon: Icons.task_alt),
                MenuCard(title: 'مستوى', icon: Icons.star),
                MenuCard(title: 'المتجر', icon: Icons.store),
                MenuCard(title: 'جدار الشرف', icon: Icons.shield),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class StatItem extends StatelessWidget {
  final String title;
  final String count;

  const StatItem({super.key, required this.title, required this.count});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          count,
          style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 4),
        Text(title, style: const TextStyle(color: Colors.grey)),
      ],
    );
  }
}

class MenuCard extends StatelessWidget {
  final String title;
  final IconData icon;

  const MenuCard({super.key, required this.title, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: const Color(0xFF1E1E1E),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: Colors.pinkAccent, size: 28),
          const SizedBox(height: 7),
          Text(title, style: const TextStyle(fontSize: 12)),
        ],
      ),
    );
  }
}

class VoiceRoomScreen extends StatefulWidget {
  const VoiceRoomScreen({super.key});

  @override
  State<VoiceRoomScreen> createState() => _VoiceRoomScreenState();
}

class _VoiceRoomScreenState extends State<VoiceRoomScreen> {
  bool muted = false;
  int? activeSeat;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('مجلس الملوك'),
        actions: [
          Container(
            margin: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
            decoration: BoxDecoration(
              color: Colors.red,
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Text(
              'LIVE 149',
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 4, 16, 10),
            child: Align(
              alignment: Alignment.centerRight,
              child: Text(
                'غرفة صوتية • 10 مقاعد',
                style: TextStyle(color: Colors.grey),
              ),
            ),
          ),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: 10,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 5,
                mainAxisSpacing: 18,
                crossAxisSpacing: 10,
                childAspectRatio: .72,
              ),
              itemBuilder: (context, i) {
                final selected = activeSeat == i;
                return GestureDetector(
                  onTap: () => setState(() => activeSeat = selected ? null : i),
                  child: Column(
                    children: [
                      Expanded(
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 180),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: const Color(0xFF292929),
                            border: Border.all(
                              color: selected
                                  ? Colors.amber
                                  : Colors.pinkAccent,
                              width: selected ? 3 : 2,
                            ),
                            boxShadow: selected
                                ? [
                                    const BoxShadow(
                                      color: Colors.amber,
                                      blurRadius: 12,
                                    ),
                                  ]
                                : null,
                          ),
                          child: Center(
                            child: Icon(
                              selected ? Icons.mic : Icons.person,
                              color: selected
                                  ? Colors.amber
                                  : Colors.white70,
                              size: 25,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 5),
                      Text(
                        selected ? 'أنت' : 'المقعد ${i + 1}',
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 10,
                          color: selected ? Colors.amber : Colors.grey,
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
          Container(
            padding: const EdgeInsets.fromLTRB(8, 12, 8, 12),
            decoration: const BoxDecoration(
              color: Color(0xFF1E1E1E),
              borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _ActionButton(
                  icon: Icons.chat_bubble_outline,
                  label: 'دردشة',
                  onTap: () => _showMessage(context),
                ),
                _ActionButton(
                  icon: Icons.star,
                  label: 'نجمة',
                  color: Colors.amber,
                  onTap: () {},
                ),
                _ActionButton(
                  icon: muted ? Icons.mic_off : Icons.mic,
                  label: muted ? 'مكتوم' : 'مايك',
                  color: muted ? Colors.redAccent : Colors.white,
                  onTap: () => setState(() => muted = !muted),
                ),
                _ActionButton(
                  icon: Icons.card_giftcard,
                  label: 'هدية',
                  color: Colors.pinkAccent,
                  onTap: () => _showGift(context),
                ),
                _ActionButton(
                  icon: Icons.sports_esports,
                  label: 'لعبة',
                  color: Colors.cyan,
                  onTap: () {},
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showMessage(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1E1E1E),
      builder: (_) => const Padding(
        padding: EdgeInsets.all(24),
        child: Text(
          'الدردشة المباشرة ستكون جاهزة عند ربط التطبيق بخادم المحادثة.',
          textAlign: TextAlign.center,
        ),
      ),
    );
  }

  void _showGift(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1E1E1E),
      builder: (_) => const Padding(
        padding: EdgeInsets.all(24),
        child: Text(
          '🎁 الهدايا — هذه واجهة أولية، ويمكن إضافة العملات والهدايا لاحقاً.',
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _ActionButton({
    required this.icon,
    required this.label,
    required this.onTap,
    this.color = Colors.white,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(30),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 6),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: color, size: 25),
            const SizedBox(height: 4),
            Text(label, style: const TextStyle(fontSize: 9)),
          ],
        ),
      ),
    );
  }
}
