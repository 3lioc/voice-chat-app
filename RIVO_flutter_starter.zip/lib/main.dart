import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

const brand = Color(0xFF7C4DFF);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Replace these two placeholders with the project's public Supabase URL/key.
  await Supabase.initialize(
    url: const String.fromEnvironment('SUPABASE_URL', defaultValue: ''),
    anonKey: const String.fromEnvironment('SUPABASE_ANON_KEY', defaultValue: ''),
  );
  runApp(const RivoApp());
}

class RivoApp extends StatelessWidget {
  const RivoApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'RIVO',
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: brand, brightness: Brightness.dark),
    home: const HomePage(),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}
class _HomePageState extends State<HomePage> {
  int tab = 0;
  final rooms = const [
    ('مجلس ريفو', '12', Icons.mic),
    ('سوالف الليل', '8', Icons.nightlife),
    ('أصدقاء ريفو', '5', Icons.groups),
  ];
  @override
  Widget build(BuildContext context) {
    final pages = [
      ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('RIVO', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          const Text('مجتمع صوتي حقيقي', style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CreateRoomPage())),
            icon: const Icon(Icons.add),
            label: const Text('إنشاء غرفة صوتية'),
          ),
          const SizedBox(height: 18),
          const Text('الغرف النشطة', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          ...rooms.map((r) => Card(
            child: ListTile(
              leading: CircleAvatar(backgroundColor: brand, child: Icon(r.$3)),
              title: Text(r.$1),
              subtitle: Text('${r.$2} مستمعين الآن'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => RoomPage(name: r.$1))),
            ),
          )),
        ],
      ),
      const Center(child: Text('اكتشف أشخاصًا وغرفًا جديدة', style: TextStyle(fontSize: 18))),
      const Center(child: Text('الإشعارات ستظهر هنا', style: TextStyle(fontSize: 18))),
      const Center(child: Text('الملف الشخصي', style: TextStyle(fontSize: 18))),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('RIVO'),
        actions: [IconButton(icon: const Icon(Icons.settings), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsPage())))],
      ),
      body: pages[tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.explore_outlined), selectedIcon: Icon(Icons.explore), label: 'اكتشف'),
          NavigationDestination(icon: Icon(Icons.notifications_outlined), selectedIcon: Icon(Icons.notifications), label: 'التنبيهات'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'حسابي'),
        ],
      ),
    );
  }
}

class RoomPage extends StatefulWidget {
  final String name;
  const RoomPage({super.key, required this.name});
  @override State<RoomPage> createState() => _RoomPageState();
}
class _RoomPageState extends State<RoomPage> {
  bool muted = true;
  final messages = <String>[];
  final controller = TextEditingController();
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.name), actions: [IconButton(onPressed: () {}, icon: const Icon(Icons.more_vert))]),
    body: Column(children: [
      Expanded(child: GridView.builder(
        padding: const EdgeInsets.all(16), itemCount: 10,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 5, crossAxisSpacing: 10, mainAxisSpacing: 16),
        itemBuilder: (_, i) => Column(children: [
          CircleAvatar(radius: 28, backgroundColor: i == 0 ? brand : Colors.white12, child: Icon(i == 0 ? Icons.person : Icons.mic_none)),
          const SizedBox(height: 5), Text(i == 0 ? 'أنت' : 'مقعد ${i+1}', style: const TextStyle(fontSize: 11)),
        ]),
      )),
      if (messages.isNotEmpty) ...messages.map((m) => Align(alignment: Alignment.centerRight, child: Padding(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2), child: Text(m)))),
      Row(children: [
        Expanded(child: TextField(controller: controller, decoration: const InputDecoration(hintText: 'اكتب رسالة...', border: OutlineInputBorder()))),
        IconButton(onPressed: () { if(controller.text.trim().isNotEmpty) setState(() { messages.add(controller.text.trim()); controller.clear(); }); }, icon: const Icon(Icons.send)),
      ]),
      SafeArea(child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
        FilledButton.icon(onPressed: () => setState(() => muted = !muted), icon: Icon(muted ? Icons.mic_off : Icons.mic), label: Text(muted ? 'فتح المايك' : 'كتم المايك')),
        OutlinedButton.icon(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.exit_to_app), label: const Text('خروج')),
      ])),
    ]),
  );
}

class CreateRoomPage extends StatelessWidget {
  const CreateRoomPage({super.key});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('إنشاء غرفة')),
    body: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
      const TextField(decoration: InputDecoration(labelText: 'اسم الغرفة')),
      const SizedBox(height: 16),
      FilledButton(onPressed: () => Navigator.pop(context), child: const Text('إنشاء')),
    ])),
  );
}
class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('الإعدادات')),
    body: ListView(children: [
      SwitchListTile(value: true, onChanged: (_) {}, title: const Text('الإشعارات')),
      ListTile(leading: const Icon(Icons.language), title: const Text('اللغة'), onTap: () {}),
      ListTile(leading: const Icon(Icons.security), title: const Text('الخصوصية والأمان'), onTap: () {}),
      ListTile(leading: const Icon(Icons.report), title: const Text('التبليغ والدعم'), onTap: () {}),
    ]),
  );
}
