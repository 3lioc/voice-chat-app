create table if not exists public.rooms (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  owner_id uuid,
  created_at timestamptz not null default now()
);
alter table public.rooms enable row level security;
create policy "rooms readable" on public.rooms for select using (true);
