# مجلس الملوك — Flutter + Agora RTC

تطبيق غرفة صوتية عربية مبني بـ Flutter ويستخدم Agora RTC.

## يعمل حالياً
- غرفة صوتية حقيقية عبر Agora RTC.
- طلب صلاحية الميكروفون على Android.
- دخول/مغادرة الغرفة.
- نشر صوت المستخدم وسماع المستخدمين الآخرين.
- كتم/فتح الميكروفون.
- تبديل السماعة.
- عرض المستخدمين في 10 مقاعد.
- شاشة إعداد App ID وTemporary Token واسم القناة.
- دعم GitHub Actions لإنتاج APK.

## مهم قبل الإنتاج
لا تضع **App Certificate** داخل التطبيق ولا ترفعها إلى GitHub.
Temporary Token مناسب للاختبار فقط. للإنتاج استخدم Token Server.

## تشغيل GitHub Actions
1. ارفع محتويات هذا المشروع إلى مستودع GitHub، بحيث يكون `pubspec.yaml` في جذر المستودع.
2. من GitHub افتح **Settings → Secrets and variables → Actions**.
3. أضف:
   - `AGORA_APP_ID` = App ID
   - `AGORA_TOKEN` = Temporary Token للاختبار
4. شغّل **Actions → Build APK → Run workflow**.
5. اترك اسم القناة `test` إذا كان الـ Temporary Token الذي أنشأته مرتبطاً بالقناة `test`.
6. بعد نجاح البناء افتح الـ run ثم **Artifacts** وحمّل `voice-chat-app-apk`.

> إذا لم تضف Secrets، سيظل التطبيق يبني، ويمكن إدخال App ID وTemporary Token من شاشة إعداد Agora داخل التطبيق.

## تشغيل محلياً
```bash
flutter pub get
flutter run
```

وللبناء مع القيم:
```bash
flutter build apk --release   --dart-define=AGORA_APP_ID=YOUR_APP_ID   --dart-define=AGORA_TOKEN=YOUR_TEMP_TOKEN   --dart-define=AGORA_CHANNEL=test
```
