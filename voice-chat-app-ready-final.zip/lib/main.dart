import 'dart:async';

import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _pink = Color(0xFFFF3D86);
const _bg = Color(0xFF121212);
const _panel = Color(0xFF1E1E1E);
const _muted = Color(0xFF9E9E9E);

// You can also build with:
// --dart-define=AGORA_APP_ID=... --dart-define=AGORA_TOKEN=... --dart-define=AGORA_CHANNEL=test
const _buildAppId = String.fromEnvironment('AGORA_APP_ID');
const _buildToken = String.fromEnvironment('AGORA_TOKEN');
const _buildChannel = String.fromEnvironment('AGORA_CHANNEL', defaultValue: 'test');

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const VoiceChatApp());
}

class VoiceChatApp extends StatelessWidget {
  const VoiceChatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'مجلس الملوك',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: _bg,
        colorScheme: ColorScheme.fromSeed(
          seedColor: _pink,
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF180F14),
          foregroundColor: Colors.white,
          centerTitle: false,
        ),
      ),
      locale: const Locale('ar'),
      home: const MainNavigator(),
    );
  }
}

class AppConfig {
  final String appId;
  final String token;
  final String channel;

  const AppConfig({required this.appId, required this.token, required this.channel});

  bool get isValid => appId.isNotEmpty && token.isNotEmpty && channel.isNotEmpty;
}

class MainNavigator extends StatefulWidget {
  const MainNavigator({super.key});

  @override
  State<MainNavigator> createState() => _MainNavigatorState();
}

class _MainNavigatorState extends State<MainNavigator> {
  int index = 1;
  AppConfig? config;

  @override
  void initState() {
    super.initState();
    _loadConfig();
  }

  Future<void> _loadConfig() async {
    final prefs = await SharedPreferences.getInstance();
    final appId = prefs.getString('agora_app_id') ?? _buildAppId;
    final token = prefs.getString('agora_token') ?? _buildToken;
    final channel = prefs.getString('agora_channel') ?? _buildChannel;
    if (!mounted) return;
    setState(() {
      config = AppConfig(appId: appId, token: token, channel: channel);
    });
  }

  Future<void> _openSettings() async {
    final result = await Navigator.of(context).push<AppConfig>(
      MaterialPageRoute(
        builder: (_) => ConfigScreen(initial: config),
      ),
    );
    if (result == null || !mounted) return;
    setState(() => config = result);
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: IndexedStack(
          index: index,
          children: [
            ProfileScreen(onSettings: _openSettings),
            VoiceRoomScreen(config: config, onSettings: _openSettings),
          ],
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (value) => setState(() => index = value),
          backgroundColor: _panel,
          indicatorColor: _pink.withValues(alpha: .25),
          destinations: const [
            NavigationDestination(
              icon: Icon(Icons.person_outline),
              selectedIcon: Icon(Icons.person),
              label: 'الملف الشخصي',
            ),
            NavigationDestination(
              icon: Icon(Icons.mic_none),
              selectedIcon: Icon(Icons.mic),
              label: 'الغرفة الصوتية',
            ),
          ],
        ),
      ),
    );
  }
}

class ConfigScreen extends StatefulWidget {
  final AppConfig? initial;

  const ConfigScreen({super.key, this.initial});

  @override
  State<ConfigScreen> createState() => _ConfigScreenState();
}

class _ConfigScreenState extends State<ConfigScreen> {
  late final TextEditingController appIdController;
  late final TextEditingController tokenController;
  late final TextEditingController channelController;
  bool obscureToken = true;
  bool saving = false;

  @override
  void initState() {
    super.initState();
    appIdController = TextEditingController(text: widget.initial?.appId ?? _buildAppId);
    tokenController = TextEditingController(text: widget.initial?.token ?? _buildToken);
    channelController = TextEditingController(text: widget.initial?.channel ?? _buildChannel);
  }

  @override
  void dispose() {
    appIdController.dispose();
    tokenController.dispose();
    channelController.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final appId = appIdController.text.trim();
    final token = tokenController.text.trim();
    final channel = channelController.text.trim();
    if (appId.isEmpty || token.isEmpty || channel.isEmpty) {
      _show('املأ App ID و Token واسم القناة أولاً.');
      return;
    }

    setState(() => saving = true);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('agora_app_id', appId);
    await prefs.setString('agora_token', token);
    await prefs.setString('agora_channel', channel);
    if (!mounted) return;
    setState(() => saving = false);
    Navigator.pop(
      context,
      AppConfig(appId: appId, token: token, channel: channel),
    );
  }

  void _show(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إعداد الاتصال')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Icon(Icons.settings_voice, size: 64, color: _pink),
          const SizedBox(height: 12),
          const Text(
            'بيانات Agora',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          const Text(
            'أدخل App ID وTemporary Token اللذين أنشأتهما من Agora. لا تدخل App Certificate هنا.',
            textAlign: TextAlign.center,
            style: TextStyle(color: _muted, height: 1.5),
          ),
          const SizedBox(height: 28),
          _field(appIdController, 'App ID', Icons.key, false),
          const SizedBox(height: 14),
          _field(tokenController, 'Temporary Token', Icons.vpn_key, true),
          const SizedBox(height: 14),
          _field(channelController, 'اسم القناة', Icons.meeting_room, false),
          const SizedBox(height: 8),
          const Text(
            'للتجربة استخدم نفس اسم القناة والتوكن على الجهازين. التوكن المؤقت ينتهي حسب مدة Agora، وعند انتهائه أنشئ توكن جديد.',
            style: TextStyle(color: _muted, fontSize: 12, height: 1.5),
          ),
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: saving ? null : _save,
            icon: saving
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.save),
            label: Text(saving ? 'جاري الحفظ...' : 'حفظ الإعدادات'),
          ),
        ],
      ),
    );
  }

  Widget _field(
    TextEditingController controller,
    String label,
    IconData icon,
    bool token,
  ) {
    return TextField(
      controller: controller,
      obscureText: token && obscureToken,
      textDirection: TextDirection.ltr,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon),
        suffixIcon: token
            ? IconButton(
                onPressed: () => setState(() => obscureToken = !obscureToken),
                icon: Icon(obscureToken ? Icons.visibility : Icons.visibility_off),
              )
            : null,
        filled: true,
        fillColor: _panel,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
      ),
    );
  }
}

class ProfileScreen extends StatelessWidget {
  final VoidCallback onSettings;

  const ProfileScreen({super.key, required this.onSettings});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('الملف الشخصي'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            onPressed: onSettings,
            tooltip: 'الإعدادات',
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const CircleAvatar(
              radius: 48,
              backgroundColor: _pink,
              child: Icon(Icons.person, size: 54, color: Colors.white),
            ),
            const SizedBox(height: 10),
            const Text(
              'القيثاره نيوز',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const Text('ID: dmar1', style: TextStyle(color: Colors.grey)),
            const SizedBox(height: 24),
            const Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                StatItem(title: 'المتابعة', count: '1'),
                StatItem(title: 'المتابعين', count: '381'),
                StatItem(title: 'الزوار', count: '2.5K'),
              ],
            ),
            const SizedBox(height: 24),
            GridView.count(
              crossAxisCount: 4,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: .9,
              children: const [
                MenuCard(title: 'مهمة', icon: Icons.task_alt),
                MenuCard(title: 'مستوى', icon: Icons.star),
                MenuCard(title: 'المتجر', icon: Icons.store),
                MenuCard(title: 'جدار الشرف', icon: Icons.shield),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class StatItem extends StatelessWidget {
  final String title;
  final String count;

  const StatItem({super.key, required this.title, required this.count});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(count, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
        const SizedBox(height: 4),
        Text(title, style: const TextStyle(color: Colors.grey)),
      ],
    );
  }
}

class MenuCard extends StatelessWidget {
  final String title;
  final IconData icon;

  const MenuCard({super.key, required this.title, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: _panel,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: _pink, size: 28),
          const SizedBox(height: 7),
          Text(title, style: const TextStyle(fontSize: 12)),
        ],
      ),
    );
  }
}

class VoiceRoomScreen extends StatefulWidget {
  final AppConfig? config;
  final VoidCallback onSettings;

  const VoiceRoomScreen({super.key, required this.config, required this.onSettings});

  @override
  State<VoiceRoomScreen> createState() => _VoiceRoomScreenState();
}

class _VoiceRoomScreenState extends State<VoiceRoomScreen> {
  RtcEngine? _engine;
  final Set<int> _remoteUsers = <int>{};
  final Set<int> _mutedRemoteUsers = <int>{};
  int? _localUid;
  bool _joined = false;
  bool _muted = false;
  bool _speaker = true;
  bool _busy = false;
  String? _error;
  String? _joinedChannel;

  @override
  void didUpdateWidget(covariant VoiceRoomScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.config?.appId != widget.config?.appId && _joined) {
      _leave();
    }
  }

  @override
  void dispose() {
    _disposeEngine();
    super.dispose();
  }

  Future<void> _disposeEngine() async {
    final engine = _engine;
    if (engine == null) return;
    try {
      await engine.leaveChannel();
      await engine.release();
    } catch (_) {}
    _engine = null;
  }

  Future<bool> _requestMic() async {
    final status = await Permission.microphone.request();
    if (status.isGranted) return true;
    if (!mounted) return false;
    setState(() => _error = status.isPermanentlyDenied
        ? 'صلاحية المايك مرفوضة نهائياً. افتح إعدادات التطبيق وفعّل الميكروفون.'
        : 'لا يمكن الدخول بدون صلاحية الميكروفون.');
    return false;
  }

  Future<void> _join() async {
    final config = widget.config;
    if (config == null || !config.isValid) {
      widget.onSettings();
      return;
    }
    if (_busy || _joined) return;

    setState(() {
      _busy = true;
      _error = null;
    });

    try {
      if (!await _requestMic()) return;

      final engine = createAgoraRtcEngine();
      _engine = engine;
      await engine.initialize(
        RtcEngineContext(
          appId: config.appId,
          channelProfile: ChannelProfileType.channelProfileLiveBroadcasting,
        ),
      );

      engine.registerEventHandler(
        RtcEngineEventHandler(
          onError: (ErrorCodeType err, String msg) {
            if (!mounted) return;
            setState(() => _error = 'Agora: ${err.name} — $msg');
          },
          onJoinChannelSuccess: (RtcConnection connection, int elapsed) {
            if (!mounted) return;
            setState(() {
              _joined = true;
              _localUid = connection.localUid;
              _joinedChannel = connection.channelId;
            });
          },
          onUserJoined: (RtcConnection connection, int uid, int elapsed) {
            if (!mounted) return;
            setState(() => _remoteUsers.add(uid));
          },
          onUserOffline: (RtcConnection connection, int uid, UserOfflineReasonType reason) {
            if (!mounted) return;
            setState(() {
              _remoteUsers.remove(uid);
              _mutedRemoteUsers.remove(uid);
            });
          },
          onUserMuteAudio: (RtcConnection connection, int uid, bool muted) {
            if (!mounted) return;
            setState(() {
              if (muted) {
                _mutedRemoteUsers.add(uid);
              } else {
                _mutedRemoteUsers.remove(uid);
              }
            });
          },
          onLeaveChannel: (RtcConnection connection, RtcStats stats) {
            if (!mounted) return;
            setState(() {
              _joined = false;
              _localUid = null;
              _remoteUsers.clear();
              _mutedRemoteUsers.clear();
            });
          },
          onTokenPrivilegeWillExpire: (RtcConnection connection, String token) {
            if (!mounted) return;
            setState(() => _error = 'التوكن قريب من الانتهاء. أنشئ Temporary Token جديداً من Agora.');
          },
        ),
      );

      await engine.enableAudio();
      await engine.setClientRole(role: ClientRoleType.clientRoleBroadcaster);
      await engine.setEnableSpeakerphone(true);
      await engine.joinChannel(
        token: config.token,
        channelId: config.channel,
        uid: 0,
        options: const ChannelMediaOptions(
          channelProfile: ChannelProfileType.channelProfileLiveBroadcasting,
          clientRoleType: ClientRoleType.clientRoleBroadcaster,
          publishMicrophoneTrack: true,
          autoSubscribeAudio: true,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = 'تعذر الاتصال: $e');
      await _disposeEngine();
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _leave() async {
    final engine = _engine;
    if (engine == null) return;
    setState(() => _busy = true);
    try {
      await engine.leaveChannel();
    } catch (_) {}
    await _disposeEngine();
    if (!mounted) return;
    setState(() {
      _joined = false;
      _localUid = null;
      _remoteUsers.clear();
      _mutedRemoteUsers.clear();
      _joinedChannel = null;
      _busy = false;
    });
  }

  Future<void> _toggleMute() async {
    final engine = _engine;
    if (engine == null || !_joined) return;
    final next = !_muted;
    try {
      await engine.muteLocalAudioStream(next);
      if (mounted) setState(() => _muted = next);
    } catch (e) {
      if (mounted) setState(() => _error = 'فشل تغيير المايك: $e');
    }
  }

  Future<void> _toggleSpeaker() async {
    final engine = _engine;
    if (engine == null || !_joined) return;
    final next = !_speaker;
    try {
      await engine.setEnableSpeakerphone(next);
      if (mounted) setState(() => _speaker = next);
    } catch (e) {
      if (mounted) setState(() => _error = 'فشل تغيير السماعة: $e');
    }
  }

  Future<void> _resetConnection() async {
    if (_joined) await _leave();
    widget.onSettings();
  }

  @override
  Widget build(BuildContext context) {
    final config = widget.config;
    final configured = config?.isValid ?? false;
    final remoteList = _remoteUsers.toList()..sort();

    return Scaffold(
      appBar: AppBar(
        title: const Text('مجلس الملوك'),
        actions: [
          if (_joined)
            IconButton(
              onPressed: _leave,
              tooltip: 'مغادرة',
              icon: const Icon(Icons.call_end, color: Colors.redAccent),
            ),
          IconButton(
            onPressed: _resetConnection,
            tooltip: 'إعدادات Agora',
            icon: const Icon(Icons.settings_outlined),
          ),
          Container(
            margin: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
            decoration: BoxDecoration(
              color: _joined ? Colors.red : Colors.grey.shade800,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              _joined ? 'LIVE' : 'OFFLINE',
              style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 6, 16, 8),
            child: Row(
              children: [
                const Icon(Icons.meeting_room_outlined, size: 18, color: _muted),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    configured
                        ? 'غرفة صوتية • ${config!.channel}'
                        : 'لم يتم إعداد اتصال Agora',
                    style: const TextStyle(color: _muted),
                  ),
                ),
                if (_joined) Text('${_remoteUsers.length + 1}/10'),
              ],
            ),
          ),
          if (_error != null)
            Container(
              margin: const EdgeInsets.fromLTRB(12, 0, 12, 8),
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.red.withValues(alpha: .12),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.red.withValues(alpha: .35)),
              ),
              child: Row(
                children: [
                  const Icon(Icons.warning_amber_rounded, color: Colors.orange),
                  const SizedBox(width: 8),
                  Expanded(child: Text(_error!, style: const TextStyle(fontSize: 12))),
                  IconButton(
                    onPressed: () => setState(() => _error = null),
                    icon: const Icon(Icons.close, size: 18),
                  ),
                ],
              ),
            ),
          if (!configured)
            Expanded(child: _notConfigured())
          else
            Expanded(
              child: GridView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: 10,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 5,
                  mainAxisSpacing: 18,
                  crossAxisSpacing: 10,
                  childAspectRatio: .72,
                ),
                itemBuilder: (context, i) {
                  if (i == 0) {
                    return _Seat(
                      label: 'أنت',
                      active: _joined,
                      muted: _muted,
                      uid: _localUid,
                    );
                  }
                  final index = i - 1;
                  if (index < remoteList.length) {
                    final uid = remoteList[index];
                    return _Seat(
                      label: 'مستخدم ${uid.toString()}',
                      active: true,
                      muted: _mutedRemoteUsers.contains(uid),
                      uid: uid,
                    );
                  }
                  return _Seat(label: 'المقعد ${i + 1}', active: false, muted: false);
                },
              ),
            ),
          _bottomBar(configured),
        ],
      ),
    );
  }

  Widget _notConfigured() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.mic_off, size: 70, color: _pink),
            const SizedBox(height: 18),
            const Text(
              'جاهز للصوت الحقيقي',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            const Text(
              'أدخل App ID وTemporary Token من Agora حتى نقدر ندخل غرفة test ونشغّل المايك.',
              textAlign: TextAlign.center,
              style: TextStyle(color: _muted, height: 1.5),
            ),
            const SizedBox(height: 20),
            FilledButton.icon(
              onPressed: widget.onSettings,
              icon: const Icon(Icons.settings),
              label: const Text('إعداد Agora'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _bottomBar(bool configured) {
    return Container(
      padding: const EdgeInsets.fromLTRB(8, 12, 8, 12),
      decoration: const BoxDecoration(
        color: _panel,
        borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
      ),
      child: SafeArea(
        top: false,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _ActionButton(
              icon: Icons.chat_bubble_outline,
              label: 'دردشة',
              onTap: () => _showMessage(context),
            ),
            _ActionButton(
              icon: Icons.star,
              label: 'نجمة',
              color: Colors.amber,
              onTap: () => _showMessage(context, text: 'النجمة واجهة فقط حالياً.'),
            ),
            _ActionButton(
              icon: _joined ? (_muted ? Icons.mic_off : Icons.mic) : Icons.mic_none,
              label: _joined ? (_muted ? 'مكتوم' : 'مايك') : 'دخول',
              color: _joined && !_muted ? _pink : Colors.white,
              onTap: !configured ? widget.onSettings : (_joined ? _toggleMute : _join),
            ),
            _ActionButton(
              icon: Icons.volume_up,
              label: _speaker ? 'سماعة' : 'سماعة خارجية',
              color: Colors.cyan,
              onTap: _joined ? _toggleSpeaker : () => _showMessage(context, text: 'ادخل الغرفة أولاً.'),
            ),
            _ActionButton(
              icon: Icons.card_giftcard,
              label: 'هدية',
              color: _pink,
              onTap: () => _showMessage(context, text: 'الهدايا تحتاج نظام حسابات/عملات لاحقاً.'),
            ),
          ],
        ),
      ),
    );
  }

  void _showMessage(BuildContext context, {String? text}) {
    showModalBottomSheet(
      context: context,
      backgroundColor: _panel,
      builder: (_) => Padding(
        padding: const EdgeInsets.all(24),
        child: Text(
          text ?? 'الدردشة الحقيقية تحتاج خدمة رسائل/Backend. الصوت الآن مربوط بـAgora RTC.',
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}

class _Seat extends StatelessWidget {
  final String label;
  final bool active;
  final bool muted;
  final int? uid;

  const _Seat({required this.label, required this.active, required this.muted, this.uid});

  @override
  Widget build(BuildContext context) {
    final borderColor = active ? (muted ? Colors.orange : _pink) : Colors.pinkAccent;
    return Column(
      children: [
        Expanded(
          child: Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFF292929),
              border: Border.all(color: borderColor, width: active ? 3 : 2),
              boxShadow: active
                  ? [BoxShadow(color: borderColor.withValues(alpha: .25), blurRadius: 10)]
                  : null,
            ),
            child: Center(
              child: Icon(
                muted ? Icons.mic_off : (active ? Icons.mic : Icons.person),
                color: active ? borderColor : Colors.white70,
                size: 25,
              ),
            ),
          ),
        ),
        const SizedBox(height: 5),
        Text(
          label,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            fontSize: 9,
            color: active ? borderColor : Colors.grey,
          ),
        ),
        if (uid != null)
          Text('UID $uid', style: const TextStyle(fontSize: 7, color: Colors.grey)),
      ],
    );
  }
}

class _ActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _ActionButton({
    required this.icon,
    required this.label,
    required this.onTap,
    this.color = Colors.white,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(30),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 5),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: color, size: 25),
            const SizedBox(height: 4),
            Text(label, style: const TextStyle(fontSize: 8)),
          ],
        ),
      ),
    );
  }
}
